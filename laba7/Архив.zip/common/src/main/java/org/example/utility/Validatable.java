package org.example.utility;

public interface Validatable {
    boolean validate();
}
